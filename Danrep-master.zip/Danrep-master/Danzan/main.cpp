#include <iostream>
#include <math.h>

using namespace std;

int main()
{
 double A,B,C,R,a,b,c;
 cin>>A,B,C,R;
 a=R*2*sin((A*3,14)/180);
 b=R*2*sin((B*3,14)/180);
 c=R*2*sin((C*3,14)/180);
 cout<<a<<b<<c;
 return 0;
}
